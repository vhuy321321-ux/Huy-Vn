package com.goalflow.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.webkit.ValueCallback
import android.widget.Toast
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var uploadMessage: ValueCallback<Array<Uri>>? = null
    private var pendingBackupJson: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                val callback = filePathCallback ?: return false
                this@MainActivity.uploadMessage?.onReceiveValue(null)
                this@MainActivity.uploadMessage = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "application/json"
                }
                return try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST)
                    true
                } catch (_: Exception) {
                    this@MainActivity.uploadMessage?.onReceiveValue(null)
                    this@MainActivity.uploadMessage = null
                    false
                }
            }
        }
            addJavascriptInterface(GoalFlowBridge(this@MainActivity), "GoalFlowBridge")
        }
        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            FILE_CHOOSER_REQUEST -> {
                val uri = if (resultCode == RESULT_OK) data?.data else null
                uploadMessage?.onReceiveValue(uri?.let { arrayOf(it) })
                uploadMessage = null
            }
            BACKUP_REQUEST -> {
                val uri = if (resultCode == RESULT_OK) data?.data else null
                val json = pendingBackupJson
                if (uri != null && json != null) {
                    try {
                        contentResolver.openOutputStream(uri)?.use { output ->
                            output.write(json.toByteArray(Charsets.UTF_8))
                        } ?: throw IllegalStateException("Unable to open backup destination")
                        Toast.makeText(this, "Đã lưu bản sao lưu.", Toast.LENGTH_SHORT).show()
                    } catch (_: Exception) {
                        Toast.makeText(this, "Không thể lưu bản sao lưu.", Toast.LENGTH_LONG).show()
                    }
                }
                pendingBackupJson = null
            }
        }
    }

    internal fun requestBackupExport(json: String) {
        pendingBackupJson = json
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "goalflow-backup.json")
        }
        try {
            startActivityForResult(intent, BACKUP_REQUEST)
        } catch (_: Exception) {
            pendingBackupJson = null
            Toast.makeText(this, "Không thể mở nơi lưu bản sao lưu.", Toast.LENGTH_LONG).show()
        }
    }

    companion object {
        private const val FILE_CHOOSER_REQUEST = 4101
        private const val BACKUP_REQUEST = 4102
    }
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    class GoalFlowBridge(private val activity: MainActivity) {
        @JavascriptInterface
        fun exportBackup(json: String) {
            activity.runOnUiThread { activity.requestBackupExport(json) }
        }
        @JavascriptInterface
        fun sync(json: String) {
            try {
                val obj = JSONObject(json)
                val arr = obj.optJSONArray("tasks") ?: JSONArray()
                val tasks = (0 until arr.length()).mapNotNull { i ->
                    val item = arr.optJSONObject(i) ?: return@mapNotNull null
                    GoalTask(
                        id = item.optString("id", ""),
                        title = item.optString("title", ""),
                        dueDate = item.optString("date", item.optString("dueDate", "")),
                        done = item.optBoolean("done", false)
                    )
                }
                val plan = GoalPlan(
                    title = obj.optString("goal", obj.optString("title", "Mục tiêu của bạn")),
                    deadline = obj.optString("deadline", ""),
                    tasks = tasks
                )
                activity.runOnUiThread { GoalData.save(activity, plan) }
            } catch (_: Exception) {
                // Ignore malformed or incomplete data rather than crashing the app.
            }
        }
    }
}
