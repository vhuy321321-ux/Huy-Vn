package com.goalflow.app

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import org.json.JSONArray

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            webViewClient = WebViewClient()
            webChromeClient = WebChromeClient()
            addJavascriptInterface(GoalFlowBridge(this@MainActivity), "GoalFlowBridge")
        }
        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    class GoalFlowBridge(private val activity: Activity) {
        @JavascriptInterface
        fun sync(json: String) {
            try {
                val obj = JSONObject(json)
                val arr = obj.optJSONArray("tasks") ?: JSONArray()
                val tasks = (0 until arr.length()).mapNotNull { i ->
                    val item = arr.optJSONObject(i) ?: return@mapNotNull null
                    GoalTask(
                        id = item.optString("id", ""),
                        title = item.optString("title", ""),
                        dueDate = item.optString("date", item.optString("dueDate", "")),
                        done = item.optBoolean("done", false)
                    )
                }
                val plan = GoalPlan(
                    title = obj.optString("goal", obj.optString("title", "Mục tiêu của bạn")),
                    deadline = obj.optString("deadline", ""),
                    tasks = tasks
                )
                activity.runOnUiThread { GoalData.save(activity, plan) }
            } catch (_: Exception) {
                // Ignore malformed or incomplete data rather than crashing the app.
            }
        }
    }
}
