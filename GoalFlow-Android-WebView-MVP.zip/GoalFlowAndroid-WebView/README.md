# GoalFlow Android WebView MVP (v0.2.0)

This is the first Android wrapper around the phone-first GoalFlow HTML prototype.

## Included
- App UI loaded from `app/src/main/assets/index.html` (no external website needed).
- Local browser storage for goal/task edits and backup export/import.
- Native Android home-screen widget for goal progress and next unfinished task.
- A JavaScript bridge that sends goal/task state to Android so the widget can refresh.

## Build an APK
This repository is source code, not an APK. Build on a computer with Android SDK installed:
1. Open the folder in Android Studio.
2. Let Gradle sync and install Android SDK Platform 35 if prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.

Or push this project to a GitHub repository and run the `Build GoalFlow APK` workflow under Actions. Download the `GoalFlow-debug-apk` artifact after the workflow succeeds.

## Current limitations
- No Notion sync or AI integration yet.
- The app has not been compiled or tested on a physical Android device in this environment.
- HTML localStorage and Android widget state are separate stores; the app syncs widget data whenever the page saves. Clearing app data may erase local app data.
- Treat this as an MVP and back up your tasks using Export backup.
